'use strict';
/* YowisBen Bot Controller — entry point (parent).
 * Express (web admin + API) selalu hidup; proses bot Telegram dijalankan
 * sebagai child process sehingga start / restart / stop bisa dikendalikan
 * realtime dari web tanpa mematikan web admin. */

const express = require('express');
const path = require('path');
const fs = require('fs');
const os = require('os');
const crypto = require('crypto');
const { spawn, spawnSync } = require('child_process');
const { loadEnv, readJson, writeJson, ensureDir, ts } = require('./util');
const gemini = require('./ai/gemini');
const templates = require('./ai/templates');
const pluginLoader = require('./bot/pluginLoader');

loadEnv();

const ROOT = path.join(__dirname, '..');
const DATA_DIR = path.join(ROOT, 'data');
const PUBLIC_DIR = path.join(ROOT, 'public');
const VERIFIED_FILE = path.join(DATA_DIR, 'verified.json');
const STATS_FILE = path.join(DATA_DIR, 'stats.json');
const PLUGIN_STATE_FILE = path.join(DATA_DIR, 'plugin_state.json');
ensureDir(DATA_DIR);
ensureDir(pluginLoader.PLUGINS_DIR);

const PORT = Number(process.env.PORT) || 3000;

/* Konfigurasi bisa diubah langsung dari panel (halaman Pengaturan):
 * nilai ditulis ke file .env + process.env, lalu bot di-restart agar nilai baru dipakai.
 * Tidak perlu lagi buka Railway > Variables untuk mengisi token. */
const ENV_FILE = path.join(ROOT, '.env');
const ENV_KEYS = ['BOT_TOKEN', 'ADMIN_ID', 'ADMIN_PASSWORD', 'GEMINI_API_KEY', 'AI_API_KEY', 'AI_PROVIDER', 'AI_BASE_URL', 'AI_TEXT_MODEL', 'AI_VISION_MODEL', 'NETLIFY_TOKEN', 'WA_CHANNEL_LINK', 'BOT_AUTOSTART', 'GEMINI_MODEL'];

function adminPassword() { return (process.env.ADMIN_PASSWORD || 'yowisben').trim(); }
function sessionToken() { return crypto.createHmac('sha256', adminPassword()).update('yowisben-admin-v1').digest('hex'); }

const AUTOSTART = process.env.BOT_AUTOSTART !== 'false';
const MOCK = process.env.MOCK_BOT === '1';

/* ---------------- ring buffer log + SSE ---------------- */
const logs = [];
let logSeq = 0;
const sseClients = new Set();
const MAX_LOGS = 800;

function addLog(level, msg) {
  const entry = { seq: ++logSeq, t: ts(), level, msg: String(msg) };
  logs.push(entry);
  if (logs.length > MAX_LOGS) logs.shift();
  const payload = `data: ${JSON.stringify(entry)}\n\n`;
  for (const res of sseClients) {
    try { res.write(payload); } catch { /* klien putus */ }
  }
}

/* ---------------- statistik ---------------- */
const stats = readJson(STATS_FILE, { apkDeploys: 0, webDeploys: 0, videoDownloads: 0, audioDownloads: 0, verifications: 0, aiFeatures: 0, webgen: 0, osint: 0, scans: 0, broadcasts: 0 });
const saveStats = () => writeJson(STATS_FILE, stats);

/* ---------------- process manager bot ---------------- */
const WORKER_PATH = path.join(__dirname, 'bot', 'worker.js');
const botState = {
  child: null,
  state: 'stopped', // stopped | starting | running | stopping
  pid: null,
  startedAt: null,
  crashes: 0,
  manualStop: false,
  botUsername: null,
  lastError: null, // alasan terakhir proses bot mati (ditampilkan di dashboard)
};

function startBot() {
  if (botState.child) return;
  botState.manualStop = false;
  botState.state = 'starting';
  addLog('system', 'Menjalankan proses bot…');
  const child = spawn(process.execPath, [WORKER_PATH], { stdio: ['ignore', 'pipe', 'pipe', 'ipc'], env: process.env });
  botState.child = child;
  botState.pid = child.pid;
  child.stdout.on('data', (d) => String(d).split('\n').filter(Boolean).forEach((l) => addLog('info', `[pid] ${l}`)));
  child.stderr.on('data', (d) => String(d).split('\n').filter(Boolean).forEach((l) => addLog('warn', `[pid] ${l}`)));
  child.on('message', (m) => {
    if (!m || typeof m !== 'object') return;
    if (m.type === 'log') {
      if (m.level === 'error') botState.lastError = m.msg;
      addLog(m.level || 'info', m.msg);
    }
    else if (m.type === 'stat') { stats[m.key] = (stats[m.key] || 0) + (m.n || 1); saveStats(); }
    else if (m.type === 'ready') {
      botState.state = 'running';
      botState.startedAt = Date.now();
      botState.crashes = 0;
      botState.lastError = null;
      botState.botUsername = m.username || botState.botUsername;
      addLog('system', `Bot online${m.username ? ` sebagai @${m.username}` : ''}.`);
    }
  });
  child.on('exit', (code, sig) => {
    botState.child = null;
    botState.pid = null;
    const wasRunning = botState.state === 'running';
    botState.state = 'stopped';
    botState.startedAt = null;
    addLog(wasRunning ? 'warn' : 'error', `Proses bot berhenti (code=${code === null ? '-' : code}${sig ? `, sig=${sig}` : ''}).`);
    // Error konfigurasi (mis. BOT_TOKEN kosong) tidak perlu di-restart otomatis —
    // restart berulang tidak akan menyembuhkan, biar admin yang memperbaiki.
    const configError = botState.lastError && /BOT_TOKEN|ADMIN_ID/i.test(botState.lastError);
    if (!botState.manualStop && AUTOSTART && !configError && botState.crashes < 5) {
      botState.crashes++;
      addLog('system', `Auto-restart dalam 3 detik (percobaan ${botState.crashes}/5).`);
      setTimeout(() => { if (!botState.child && !botState.manualStop) startBot(); }, 3000);
    }
  });
}

function stopBot() {
  botState.manualStop = true;
  if (!botState.child) { botState.state = 'stopped'; return; }
  botState.state = 'stopping';
  addLog('system', 'Menghentikan proses bot…');
  const c = botState.child;
  const killer = setTimeout(() => { try { c.kill('SIGKILL'); } catch { /* sudah mati */ } }, 8000);
  c.once('exit', () => clearTimeout(killer));
  try { c.kill('SIGTERM'); } catch { /* diam */ }
}

function restartBot() {
  addLog('system', 'Restart bot diminta admin.');
  if (!botState.child) { startBot(); return; }
  stopBot();
  const iv = setInterval(() => {
    if (!botState.child) { clearInterval(iv); botState.manualStop = false; startBot(); }
  }, 300);
  setTimeout(() => clearInterval(iv), 15000);
}

/* ---------------- util plugin (parent) ---------------- */
const RESERVED_SLUGS = new Set(['start', 'help', 'cancel', 'deployapk', 'deployweb', 'audio', 'fitur', 'stats', 'osint', 'scan', 'buatweb', 'verif', 'unverif']);

function checkSyntax(code) {
  const tmp = path.join(os.tmpdir(), `plug-${Date.now()}-${Math.random().toString(36).slice(2)}.js`);
  fs.writeFileSync(tmp, code.endsWith('\n') ? code : code + '\n');
  const r = spawnSync(process.execPath, ['--check', tmp], { timeout: 15000 });
  fs.rmSync(tmp, { force: true });
  return r.status === 0 ? null : String(r.stderr || 'syntax error').split('\n').slice(0, 4).join('\n');
}

function uniqueSlug(slug) {
  const existing = new Set(pluginLoader.listPlugins().map((p) => p.slug));
  if (!existing.has(slug)) return slug;
  for (let i = 2; i < 99; i++) {
    if (!existing.has(`${slug}_${i}`)) return `${slug}_${i}`;
  }
  throw new Error('Tidak ada slug unik yang tersisa');
}

function reloadBot(reason) {
  if (botState.child && botState.state === 'running') {
    try { botState.child.send({ type: 'reload' }); addLog('system', `${reason} — plugin di-hot-reload di proses bot.`); return; }
    catch { /* fallback di bawah */ }
  }
  addLog('system', `${reason} — akan aktif otomatis saat bot berikutnya start.`);
}

/* ---------------- auth ---------------- */
const loginAttempts = new Map(); // ip -> { count, ts }
function rateLimited(ip) {
  const now = Date.now();
  const rec = loginAttempts.get(ip) || { count: 0, ts: now };
  if (now - rec.ts > 60000) { rec.count = 0; rec.ts = now; }
  rec.count++;
  loginAttempts.set(ip, rec);
  return rec.count > 8;
}

function requireAuth(req, res, next) {
  const m = (req.headers.cookie || '').match(/(?:^|;\s*)yb_session=([^;]+)/);
  if (m && m[1] === sessionToken()) return next();
  res.status(401).json({ error: 'Tidak punya akses. Login dulu.' });
}

/* ---------------- express ---------------- */
const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '1mb' }));
app.use(express.static(PUBLIC_DIR, { index: false, maxAge: 0 }));

app.get('/', (req, res) => res.sendFile(path.join(PUBLIC_DIR, 'index.html')));
app.get('/health', (req, res) => res.json({ ok: true, bot: botState.state, mock: MOCK }));

app.post('/api/login', (req, res) => {
  const ip = req.socket.remoteAddress || 'x';
  if (rateLimited(ip)) return res.status(429).json({ error: 'Terlalu banyak percobaan. Tunggu sebentar.' });
  if (String((req.body || {}).password || '') === adminPassword()) {
    res.setHeader('Set-Cookie', `yb_session=${sessionToken()}; HttpOnly; Path=/; Max-Age=604800; SameSite=Lax`);
    addLog('system', 'Admin masuk ke web controller.');
    return res.json({ ok: true });
  }
  return res.status(401).json({ error: 'Password salah.' });
});

app.post('/api/logout', (req, res) => {
  res.setHeader('Set-Cookie', 'yb_session=; HttpOnly; Path=/; Max-Age=0');
  res.json({ ok: true });
});

app.get('/api/status', requireAuth, (req, res) => {
  res.json({
    bot: {
      state: botState.state,
      pid: botState.pid,
      uptimeSec: botState.startedAt ? Math.floor((Date.now() - botState.startedAt) / 1000) : 0,
      username: botState.botUsername,
      autostart: AUTOSTART,
      lastError: botState.lastError,
    },
    mock: MOCK,
    stats,
    users: Object.keys(readJson(VERIFIED_FILE, {})).length,
    usersTotal: Object.keys(readJson(path.join(DATA_DIR, 'users.json'), {})).length,
    plugins: pluginLoader.listPlugins().length,
    ai: {
      gemini: gemini.available(),
      available: gemini.available(),
      vision: gemini.visionAvailable(),
      provider: (gemini.providerInfo() || { name: 'Template offline' }).name,
    },
  });
});

/* ---------------- konfigurasi via panel (Pengaturan) ---------------- */
function maskValue(v) {
  if (!v) return null;
  return v.length > 10 ? `${v.slice(0, 4)}…${v.slice(-4)}` : '•••••';
}

function readEnvFileMap() {
  const out = {};
  try {
    for (const line of fs.readFileSync(ENV_FILE, 'utf8').split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
      if (m) out[m[1]] = m[2];
    }
  } catch { /* file belum ada */ }
  return out;
}

app.get('/api/env', requireAuth, (req, res) => {
  res.json({
    env: ENV_KEYS.map((k) => {
      const cur = (process.env[k] || '').trim();
      const fromFile = readEnvFileMap()[k] || '';
      return { key: k, set: cur.length > 0, mask: maskValue(cur), inEnvFile: fromFile.length > 0 };
    }),
  });
});

app.post('/api/env', requireAuth, async (req, res) => {
  const body = req.body || {};
  const updates = {};
  for (const k of ENV_KEYS) {
    const v = String(body[k] == null ? '' : body[k]).trim();
    if (v) updates[k] = v;
  }
  if (!Object.keys(updates).length) return res.status(400).json({ error: 'Tidak ada nilai yang diisi.' });

  // validasi per kunci — pesan kesalahan yang jelas, bukan gagal diam-diam
  if (updates.BOT_TOKEN && !/^\d+:[A-Za-z0-9_-]{30,}$/.test(updates.BOT_TOKEN)) {
    return res.status(422).json({ error: 'Format BOT_TOKEN salah. Salin utuh dari @BotFather, contoh: 1234567890:AAExx… (angka, titik dua, lalu 35 huruf/angka).' });
  }
  if (updates.ADMIN_ID && !/^\d{4,}$/.test(updates.ADMIN_ID)) {
    return res.status(422).json({ error: 'ADMIN_ID harus angka Telegram ID (contoh: 7596781256).' });
  }
  if (updates.ADMIN_PASSWORD && updates.ADMIN_PASSWORD.length < 6) {
    return res.status(422).json({ error: 'ADMIN_PASSWORD minimal 6 karakter.' });
  }
  if (updates.GEMINI_API_KEY && updates.GEMINI_API_KEY.length < 20) {
    return res.status(422).json({ error: 'GEMINI_API_KEY terlalu pendek. Key yang benar berawalan AIza dan panjang (dari aistudio.google.com/apikey).' });
  }
  if (updates.AI_API_KEY && updates.AI_API_KEY.length < 20) {
    return res.status(422).json({ error: 'AI_API_KEY terlalu pendek. Key Groq berawalan gsk_ (console.groq.com/keys), DeepSeek sk- (platform.deepseek.com), OpenRouter sk-or- (openrouter.ai/keys).' });
  }
  if (updates.AI_PROVIDER && !/^(gemini|groq|deepseek|openrouter|custom)$/i.test(updates.AI_PROVIDER)) {
    return res.status(422).json({ error: 'AI_PROVIDER hanya boleh: gemini, groq, deepseek, openrouter, atau custom. Kosongkan agar dideteksi otomatis dari awalan key.' });
  }
  if (updates.AI_BASE_URL && !/^https?:\/\//i.test(updates.AI_BASE_URL)) {
    return res.status(422).json({ error: 'AI_BASE_URL harus URL lengkap (contoh: https://api.groq.com/openai/v1).' });
  }
  if ((updates.AI_TEXT_MODEL || '').length === 1 || (updates.AI_VISION_MODEL || '').length === 1) {
    return res.status(422).json({ error: 'Nama model terlalu pendek (contoh: llama-3.3-70b-versatile).' });
  }
  if (updates.AI_PROVIDER && /^custom$/i.test(updates.AI_PROVIDER) && !(updates.AI_BASE_URL || process.env.AI_BASE_URL)) {
    return res.status(422).json({ error: 'AI_PROVIDER=custom wajib disertai AI_BASE_URL (URL endpoint OpenAI-compatible).' });
  }
  if (updates.NETLIFY_TOKEN && updates.NETLIFY_TOKEN.length < 10) {
    return res.status(422).json({ error: 'NETLIFY_TOKEN terlalu pendek (harusnya berawalan nfp_).' });
  }
  if (updates.WA_CHANNEL_LINK && !/^https:\/\//i.test(updates.WA_CHANNEL_LINK)) {
    return res.status(422).json({ error: 'WA_CHANNEL_LINK harus tautan https:// saluran WhatsApp.' });
  }
  if (updates.BOT_AUTOSTART && !/^(true|false)$/i.test(updates.BOT_AUTOSTART)) {
    return res.status(422).json({ error: 'BOT_AUTOSTART hanya boleh true atau false.' });
  }

  // BOT_TOKEN divalidasi langsung ke Telegram sebelum disimpan — biar tidak ada
  // token terpotong yang bikin bot "hidup" lalu mati lagi dengan error samar.
  let tokenWarning = null;
  if (updates.BOT_TOKEN) {
    try {
      const r = await fetch(`https://api.telegram.org/bot${updates.BOT_TOKEN}/getMe`, { signal: AbortSignal.timeout(10000) });
      const j = await r.json().catch(() => null);
      if (j && j.ok === false) {
        return res.status(422).json({ error: `Token ditolak Telegram (error ${j.error_code}): ${j.description}. Buat token baru di @BotFather jika token lama sudah dicabut.` });
      }
      if (j && j.ok) tokenWarning = `Token valid untuk @${j.result.username}`;
    } catch { /* jaringan Telegram tak terjangkau sesaat — izinkan simpan */ }
  }

  // tulis ke .env (merge per baris) + perbarui process.env parent agar worker
  // berikutnya mewarisi nilai baru; password baru langsung berlaku untuk login.
  try {
    const lines = fs.existsSync(ENV_FILE) ? fs.readFileSync(ENV_FILE, 'utf8').split(/\r?\n/) : [];
    for (const [k, v] of Object.entries(updates)) {
      const idx = lines.findIndex((l) => new RegExp(`^\\s*${k}\\s*=`).test(l));
      if (idx >= 0) lines[idx] = `${k}=${v}`;
      else lines.push(`${k}=${v}`);
      process.env[k] = v;
    }
    fs.writeFileSync(ENV_FILE, lines.filter((l) => l.trim() !== '').join('\n') + '\n');
  } catch (e) {
    return res.status(500).json({ error: `Gagal menulis .env: ${e.message}` });
  }

  addLog('system', `Admin memperbarui konfigurasi dari panel: ${Object.keys(updates).join(', ')}.`);
  const botWasRunning = !!botState.child;
  if (botWasRunning) restartBot();
  const msg = `Konfigurasi tersimpan${tokenWarning ? ` — ${tokenWarning}` : ''}. ` +
    (botWasRunning ? 'Bot di-restart agar nilai baru aktif.' : 'Sekarang tekan Start (atau "Simpan & Restart Bot") untuk menyalakan bot.');
  res.json({ ok: true, msg, restarted: botWasRunning });
});

/* ---------------- broadcast (siaran ke semua pengguna bot) ---------------- */
app.post('/api/broadcast', requireAuth, (req, res) => {
  const message = String((req.body || {}).message || '').trim();
  if (message.length < 1) return res.status(400).json({ error: 'Pesan siaran tidak boleh kosong.' });
  if (message.length > 3500) return res.status(400).json({ error: 'Pesan maksimal 3500 karakter.' });
  const html = (req.body || {}).html === true;
  if (!botState.child || botState.state !== 'running') {
    return res.status(409).json({ error: 'Bot sedang tidak berjalan — nyalakan dulu (Start) sebelum menyiarkan.' });
  }
  try {
    botState.child.send({ type: 'broadcast', text: message, html });
  } catch (e) {
    return res.status(500).json({ error: 'Gagal mengirim perintah ke proses bot: ' + e.message });
  }
  addLog('system', `📣 Broadcast diminta admin (${message.length} karakter, mode ${html ? 'HTML' : 'teks'}) — dikirim bertahap ke semua pengguna.`);
  res.json({ ok: true, msg: 'Broadcast dikirim ke proses bot — progres tampil di log (tiap 25 pesan).' });
});

app.post('/api/bot/:action', requireAuth, (req, res) => {  const { action } = req.params;
  if (action === 'start') {
    if (botState.child) return res.status(409).json({ error: 'Bot sedang berjalan.' });
    startBot();
    return res.json({ ok: true, msg: 'Perintah start dikirim.' });
  }
  if (action === 'stop') {
    if (!botState.child) return res.status(409).json({ error: 'Bot memang sedang berhenti.' });
    stopBot();
    return res.json({ ok: true, msg: 'Perintah stop dikirim.' });
  }
  if (action === 'restart') {
    restartBot();
    return res.json({ ok: true, msg: 'Perintah restart dikirim.' });
  }
  return res.status(400).json({ error: 'Aksi tidak dikenal.' });
});

app.get('/api/logs', requireAuth, (req, res) => {
  const after = Number(req.query.after) || 0;
  res.json({ logs: logs.filter((l) => l.seq > after) });
});

app.get('/api/logs/export', requireAuth, (req, res) => {
  const body = logs.map((l) => `[${l.t}] ${l.level.toUpperCase()} ${l.msg}`).join('\n');
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="yowisben-log.txt"');
  res.send(body || 'log kosong');
});

app.get('/api/logs/stream', requireAuth, (req, res) => {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
  });
  res.write('retry: 3000\n\n');
  sseClients.add(res);
  const hb = setInterval(() => { try { res.write(': ping\n\n'); } catch { /* diam */ } }, 15000);
  req.on('close', () => { clearInterval(hb); sseClients.delete(res); });
});

app.get('/api/plugins', requireAuth, (req, res) => {
  const state = readJson(PLUGIN_STATE_FILE, {});
  const plugins = pluginLoader.listPlugins().map((p) => ({ ...p, enabled: state[p.slug] !== false }));
  res.json({ plugins });
});

app.post('/api/plugins/preview', requireAuth, async (req, res) => {
  const desc = String((req.body || {}).description || '').trim();
  if (desc.length < 5) return res.status(400).json({ error: 'Deskripsikan fiturnya dengan lebih jelas (min. 5 karakter).' });
  addLog('system', `Admin membuat fitur baru via AI: "${desc.slice(0, 80)}"`);
  let engine = (gemini.providerInfo() || { name: 'template' }).name;
  let aiError = null;
  let plugin;
  try {
    plugin = await gemini.generateFeature(desc);
  } catch (e) {
    aiError = e.message;
    engine = 'template';
    plugin = templates.generateFeature(desc);
    plugin.slug = uniqueSlug(plugin.slug);
  }
  const syntaxErr = checkSyntax(plugin.code);
  if (syntaxErr) return res.status(422).json({ error: `Kode hasil AI tidak valid: ${syntaxErr}`, engine });
  res.json({ plugin, engine, aiError: gemini.available() ? aiError : 'Belum ada API key AI (GEMINI_API_KEY atau AI_API_KEY) — ini template offline, bukan AI sungguhan. Untuk generator AI asli: key Groq GRATIS di console.groq.com/keys (berawalan gsk_), isi ke AI_API_KEY di Pengaturan.' });
});

app.post('/api/plugins', requireAuth, (req, res) => {
  const { name, slug, description, usage, code } = req.body || {};
  if (!/^[a-z][a-z0-9_]{2,19}$/.test(String(slug || ''))) return res.status(400).json({ error: 'Slug tidak valid.' });
  if (RESERVED_SLUGS.has(slug)) return res.status(400).json({ error: 'Slug bentrok dengan perintah bawaan bot.' });
  const syntaxErr = checkSyntax(String(code || ''));
  if (syntaxErr) return res.status(422).json({ error: `Kode tidak valid: ${syntaxErr}` });
  const d = new Date().toISOString().slice(0, 10);
  const header =
    `// @name ${name || slug}\n// @slug ${slug}\n// @description ${String(description || '').replace(/\n/g, ' ')}\n` +
    `// @usage ${usage || '/' + slug}\n// @engine ai\n// @created ${d}\n`;
  pluginLoader.savePlugin({ slug, code: header + code });
  stats.aiFeatures = (stats.aiFeatures || 0) + 1;
  saveStats();
  addLog('system', `Plugin baru diaktifkan: ${slug} (${name || slug}).`);
  reloadBot('Plugin baru ditambahkan');
  res.json({ ok: true, slug });
});

app.post('/api/plugins/:slug/toggle', requireAuth, (req, res) => {
  const { slug } = req.params;
  try {
    const state = readJson(PLUGIN_STATE_FILE, {});
    state[slug] = state[slug] === false ? true : false;
    writeJson(PLUGIN_STATE_FILE, state);
    addLog('system', `Plugin ${slug} ${state[slug] ? 'diaktifkan' : 'dinonaktifkan'}.`);
    reloadBot('Status plugin berubah');
    res.json({ ok: true, enabled: state[slug] });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.delete('/api/plugins/:slug', requireAuth, (req, res) => {
  const { slug } = req.params;
  try {
    const p = pluginLoader.pluginPath(slug);
    if (!fs.existsSync(p)) return res.status(404).json({ error: 'Plugin tidak ditemukan.' });
    pluginLoader.removePlugin(slug);
    addLog('system', `Plugin ${slug} dihapus.`);
    reloadBot('Plugin dihapus');
    res.json({ ok: true });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.get('/api/users', requireAuth, (req, res) => {
  const v = readJson(VERIFIED_FILE, {});
  const all = readJson(path.join(DATA_DIR, 'users.json'), {});
  const users = Object.entries(all)
    .map(([id, u]) => ({
      id,
      name: (u && u.name) || '-',
      username: (u && u.username) || '',
      verified: !!v[id],
      firstSeen: u && u.firstSeen,
      lastSeen: u && u.lastSeen,
    }))
    .sort((a, b) => String(b.lastSeen || '').localeCompare(String(a.lastSeen || '')));
  res.json({ users, total: users.length, verified: users.filter((u) => u.verified).length });
});

app.use('/api', (req, res) => res.status(404).json({ error: 'Endpoint tidak ditemukan.' }));

/* eslint-disable-next-line no-unused-vars */
app.use((err, req, res, next) => {
  addLog('error', `Server: ${err.message}`);
  res.status(500).json({ error: 'Kesalahan internal server.' });
});

app.listen(PORT, '0.0.0.0', () => {
  const ai = gemini.providerInfo();
  addLog('system', `Web controller siap di port ${PORT} (password admin: ${adminPassword() ? 'terpasang' : 'default "yowisben"'}, AI: ${ai ? `${ai.name} — ${ai.textModel}` : 'belum ada key — generator fitur memakai engine template, isi GEMINI_API_KEY atau AI_API_KEY di Pengaturan'}).`);
  console.log(`YowisBen Controller berjalan di :${PORT} (bot: ${botState.state})`);
});

/* ---------------- boot ---------------- */
if (AUTOSTART) setTimeout(startBot, 800);

process.on('SIGTERM', () => {
  addLog('system', 'SIGTERM — mematikan service (Railway restart/stop).');
  if (botState.child) { try { botState.child.kill('SIGTERM'); } catch { /* diam */ } }
  process.exit(0);
});
process.on('uncaughtException', (e) => addLog('error', `uncaughtException: ${e.message}`));
